+--------------------------------------------+
Prerequisite:
this demo need to install Ant.

How to run:
enter root directory of jsunit, execute ant

+--------------------------------------------+