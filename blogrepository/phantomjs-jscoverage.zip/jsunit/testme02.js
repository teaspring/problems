/**
* js file to test
*/
function divide(){
	if(arguments.length == 0)
		return 0;
	if(arguments[0] == 0)
		return 0;
	var quotient = arguments[0];   
    for (var i=1; i<arguments.length; i++)   
        if(arguments[i] == 0)
			continue;
		else
			quotient /= arguments[i];   
    return quotient;   
} 