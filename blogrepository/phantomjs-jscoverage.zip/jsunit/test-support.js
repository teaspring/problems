//create a scope so we don't pollute global   
(function() {     
   var testName; 
   //array, element is key-value pair, with filename as key, and Lines

   //arg: { name }   
    QUnit.testStart = function(t) {   
        testName = t.name;   
    };   
       
    //arg: { name, failed, passed, total }   
    QUnit.testDone = function(t) {   
        //console.log('Test "' + t.name + '" completed: ' + (0 === t.failed ? 'pass' : 'FAIL'))  
		//call getCoverageLine() once		
    };   
       
    //{ result, actual, expected, message }   
    QUnit.log = function(t) {   
        if (!t.result) {   
            //console.log('Test "' + testName + '" assertion failed. Expected <' + t.expected + '> Actual <' + t.actual + '>' + (t.message ? ': \'' + t.message + '\'' : ''));   
        }   
    };  

   //we want this at global scope so outside callers can find it. In a more realistic implementation we   
    //should probably put it in a namespace.   
    window.getCoverageByLine = function() {   
        var result = new Array();
		var key = null;   
        var lines = null;   
        //look for code coverage data       
        if (typeof _$jscoverage === 'object') {   
            for (key in _$jscoverage) {   
				lines = _$jscoverage[key];
				result.push({ 'key': key, 'lines': lines });
			}
        }    
  
        if (!lines) {   
           console.log('code coverage data is NOT available');   
        }                       
        return result;   
   };   
	
   /*
   * to support multiple files, first merge,then calculate
   */
   QUnit.done = function(t) {   
		var cvgInfoArray = getCoverageByLine();
		var resArray = new Array; 
		for(cIdx in cvgInfoArray){
			var cvgInfo = cvgInfoArray[cIdx];
			if (!!cvgInfo.lines) {
				var testableLines = 0;   
				var testedLines = 0;   
				var untestableLines = 0;   
				for (lineIdx in cvgInfo.lines) {   
					var cvg = cvgInfo.lines[lineIdx];   
					if (typeof cvg === 'number') {   
						testableLines += 1;   
						if (cvg > 0) {   
							testedLines += 1;   
						}                      
					} else {   
						untestableLines += 1;   
					}   
				}					
				var coverage = '' + Math.floor(100 * testedLines / testableLines) + '%';   
				resArray.push({"key": cvgInfo.key, "coverage": coverage});
			}
		}		      
		var result = document.getElementById('qunit-testresult');   
        if (result != null) {   
			for(rIdx in resArray){
				result.innerHTML += ' ' + resArray[rIdx].coverage + ' test coverage of ' + resArray[rIdx].key + '; '; 
				console.log(' ' + resArray[rIdx].coverage + ' test coverage of ' + resArray[rIdx].key);
			}
        } else {   
            console.log('can\'t find test-result element to update');   
        }              				
   };

	window.splitVDIFile = function(f){
		var aFile = f.split('/');
		var fileName = aFile.pop(); //pop
		var pkgName = aFile.join('/');
	};
	
}());  
