/**
* js file to test
*/
function add(){
    var sum =0;
	var count=0;
    for (var i=0; i<arguments.length; i++){   
        if(arguments[i] < 10){
			sum += arguments[i];
			count++;
		}
	}
	if(count < arguments.length){
		for (var i=0; i<arguments.length; i++){   
			if(arguments[i] >= 10){
				sum += arguments[i];   
			}
		}	
	}
    return sum;   
} 